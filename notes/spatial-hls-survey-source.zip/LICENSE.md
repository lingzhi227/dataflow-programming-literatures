# Licensing

Original editorial text, diagrams and collection metadata are licensed under [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/). Credit Dataflow Programming Literatures contributors, link to this repository and indicate changes.

Third-party PDFs retain their individual licences, recorded with their authors and source in [papers/metadata.json](https://github.com/lingzhi227/dataflow-programming-literatures/blob/main/papers/metadata.json). This licence does not apply to linked works.
