From Algorithm Semantics to Processing Elements: A Survey of Spatial High-Level Synthesis
Lingzhi Yang
Stony Brook University
10 September 2026

Build in this directory with Tectonic 0.17.0:
  tectonic spatial-hls-survey.tex

Alternatively use a current TeX distribution providing acmart and the packages
named in the preamble. All figures are inline TikZ. The generated .bbl is
included, together with the .bib source. This flat package changes only the
bibliography path from the repository version. No third-party paper PDFs,
SDK software or experimental outputs are needed to build the manuscript.

Source and research notes:
https://github.com/lingzhi227/dataflow-programming-literatures
Supporting prototype:
https://github.com/lingzhi227/MIMD_dataflow

This is an author research manuscript, not a conference publication.
