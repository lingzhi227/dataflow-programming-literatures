From Algorithm Semantics to Processing Elements: A Survey of Spatial High-Level Synthesis
Lingzhi Yang
Department of Applied Mathematics and Statistics, Stony Brook University
10 September 2026

Build in this directory with Tectonic 0.17.0:
  tectonic spatial-hls-survey.tex

Template: elsarticle 3.3 (2020-11-20), options final,3p,times,authoryear.
Bibliography style: elsarticle-harv. Both are standard TeX dependencies.
The class/options and Times-family layout match the formatting reference:
https://arxiv.org/abs/2310.18345v1
That reference is used for layout only. This manuscript has one author and
makes no journal-submission, publication or arXiv-submission claim.

Tectonic resolves the packages named in the preamble. T1 font encoding is
explicit; XeTeX-only accent mappings preserve Unicode bibliography names.
A current TeX distribution providing the same class and packages can also
build the manuscript. All figures are inline TikZ. The generated .bbl and
original .bib database are both included. The flat package changes only the
bibliography path from the repository version. No paper PDFs, SDK software
or experimental outputs are required to build this manuscript.

Source and research notes:
https://github.com/lingzhi227/dataflow-programming-literatures
Supporting prototype:
https://github.com/lingzhi227/MIMD_dataflow
